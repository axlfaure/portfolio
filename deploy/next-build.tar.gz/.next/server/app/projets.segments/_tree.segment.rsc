:HL["/_next/static/css/0740ba1432138559.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"(frontend)","param":null,"prefetchHints":4144,"slots":{"children":{"name":"projets","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"lKVbbxiSAao9d8niUNsm9"}
